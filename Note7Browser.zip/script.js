
// DOM Elements
const urlBar = document.getElementById('url-bar');
const searchBar = document.getElementById('center-search-bar');
const backButton = document.getElementById('back-button');
const forwardButton = document.getElementById('forward-button');
const refreshButton = document.getElementById('refresh-button');
const searchButton = document.getElementById('search-button');
const dangerModeButton = document.getElementById('danger-mode-button');
let dangerMode = false;

// Helper Function: Load URL or Search Query
function loadUrlOrSearch(input) {
  let url = input.trim();
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = `https://duckduckgo.com/?q=${encodeURIComponent(url)}`;
  }
  window.location.href = url;
}

// Event Listeners
backButton.addEventListener('click', () => window.history.back());
forwardButton.addEventListener('click', () => window.history.forward());
refreshButton.addEventListener('click', () => window.location.reload());

urlBar.addEventListener('keypress', (event) => {
  if (event.key === 'Enter') {
    loadUrlOrSearch(urlBar.value);
  }
});

searchBar.addEventListener('keypress', (event) => {
  if (event.key === 'Enter') {
    loadUrlOrSearch(searchBar.value);
  }
});

searchButton.addEventListener('click', () => {
  loadUrlOrSearch(searchBar.value);
});

// Danger Mode Toggle
dangerModeButton.addEventListener('click', () => {
  if (!dangerMode) {
    document.body.classList.add('danger-mode');
    dangerModeButton.textContent = "Normal Mode";
    dangerMode = true;
  } else {
    document.body.classList.remove('danger-mode');
    dangerModeButton.textContent = "Danger Mode";
    dangerMode = false;
  }
});
